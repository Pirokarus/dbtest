CREATE FUNCTION add_user (_login character varying, _ppussword character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN INSERT INTO public.users (login, password ) VALUES (_login,_ppussword); END; 
$$
