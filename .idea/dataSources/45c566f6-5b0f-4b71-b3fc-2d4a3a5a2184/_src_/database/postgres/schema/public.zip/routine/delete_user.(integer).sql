CREATE FUNCTION delete_user (_id integer) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN DELETE FROM users WHERE id = _id; END; 
$$
