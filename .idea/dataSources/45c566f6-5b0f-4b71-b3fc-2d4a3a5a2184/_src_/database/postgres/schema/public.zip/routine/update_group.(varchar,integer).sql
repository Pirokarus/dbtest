CREATE FUNCTION update_group (_name character varying, _userid integer) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN UPDATE groups SET name = _name WHERE id = _id; END; 
$$
