CREATE FUNCTION users_groups () RETURNS TABLE(user_name character varying, contacts_number integer)
	LANGUAGE plpgsql
AS $$
 BEGIN RETURN QUERY SELECT users.login,COUNT(groups.user_id) FROM groups JOIN users ON groups.user_id = users.id GROUP BY groups.user_id,users.login; END; 
$$
