CREATE FUNCTION add_contact (_firstname character varying, _lustname character varying, _number character varying, _userid integer) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN INSERT INTO contacts( firstName, lastName, number, user_id ) VALUES ( _firstName, _lustName, _number, _userId ); END; 
$$
