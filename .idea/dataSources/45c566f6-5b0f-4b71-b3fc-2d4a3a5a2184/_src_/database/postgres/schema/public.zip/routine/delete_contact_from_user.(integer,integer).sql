CREATE FUNCTION delete_contact_from_user (_contact_id integer, _group_id integer) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN DELETE FROM references_table WHERE contact_id = _contact_id AND group_id = _group_id; END; 
$$
