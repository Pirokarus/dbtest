CREATE FUNCTION avg_number_of_contacts_of_user () RETURNS integer
	LANGUAGE plpgsql
AS $$
 DECLARE i INTEGER; BEGIN SELECT avg(foo)  FROM (select count(*) as foo from contacts group by user_id) as t into i; RETURN i; END; 
$$
