CREATE FUNCTION add_group (_name character varying, _userid integer) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN INSERT INTO groups( name, user_id ) VALUES ( _name, _userId ); END; 
$$
