CREATE FUNCTION delete_contact (_id integer) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN DELETE FROM contacts WHERE id = _id; END; 
$$
