CREATE FUNCTION dream_user () RETURNS TABLE(user_name character varying)
	LANGUAGE plpgsql
AS $$
 BEGIN RETURN QUERY SELECT u.login from users u join(select user_id from contacts group by user_id having count(*)<10) c on u.id=c.user_id; END; 
$$
