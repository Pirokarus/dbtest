CREATE FUNCTION number_users () RETURNS integer
	LANGUAGE plpgsql
AS $$
 DECLARE i INTEGER; BEGIN SELECT count(*) FROM users into i; RETURN i; END; 
$$
