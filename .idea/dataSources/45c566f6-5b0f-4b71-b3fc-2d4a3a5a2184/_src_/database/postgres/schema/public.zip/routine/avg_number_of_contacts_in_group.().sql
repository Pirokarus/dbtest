CREATE FUNCTION avg_number_of_contacts_in_group () RETURNS integer
	LANGUAGE plpgsql
AS $$
 DECLARE i INTEGER; BEGIN SELECT avg(foo)  FROM (select count(*) as foo from references_table group by group_id) as t into i; RETURN i; END; 
$$
