CREATE FUNCTION add_contact_to_group (_contact_id integer, _group_id integer) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN INSERT INTO references_table( contact_id, group_id ) VALUES ( _contact_id, _group_id ); END; 
$$
