CREATE FUNCTION update_contact (_firstname character varying, _lustname character varying, _number character varying, _userid integer) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN UPDATE contacts SET firstName = _firstName, lastName = _lustName, number = _number WHERE id = _id; END; 
$$
