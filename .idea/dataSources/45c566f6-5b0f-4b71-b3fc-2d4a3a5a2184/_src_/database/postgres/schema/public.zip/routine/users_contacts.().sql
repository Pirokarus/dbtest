CREATE FUNCTION users_contacts () RETURNS TABLE(user_name character varying, contacts_number integer)
	LANGUAGE plpgsql
AS $$
 BEGIN RETURN QUERY SELECT users.login,COUNT(contacts.user_id) FROM contacts JOIN users ON contacts.user_id = users.id GROUP BY contacts.user_id,users.login; END; 
$$
