CREATE FUNCTION delete_group (_id integer) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN DELETE FROM groups WHERE id = _id; END; 
$$
