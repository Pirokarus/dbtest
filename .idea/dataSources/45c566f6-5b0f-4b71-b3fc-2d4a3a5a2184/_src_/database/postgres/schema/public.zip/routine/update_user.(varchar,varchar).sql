CREATE FUNCTION update_user (_login character varying, _ppussword character varying) RETURNS void
	LANGUAGE plpgsql
AS $$
 BEGIN UPDATE users SET login = _login, pussword = _pussword WHERE id = _id; END; 
$$
